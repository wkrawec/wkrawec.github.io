#!/bin/bash

g++ -o enc-dec enc-dec.cpp -I ./ezpwd-reed-solomon-master/c++/ezpwd/
