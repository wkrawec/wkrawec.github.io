#include <errno.h>

#if ! defined( EBADMSG )
#  define EBADMSG	9905
#endif

#if ! defined( EINVAL )
#  define EINVAL	9943
#endif
