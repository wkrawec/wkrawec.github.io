
/*
 * cpu_features -- returns bitmask indicating SIMD features of CPU
 * 
 *     Force "portable" behavior.
 */
int cpu_features( void )
{
	return 0;
}
