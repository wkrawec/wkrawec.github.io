#define EZPWD_BCH_CLASSIC
#include "bchsimple.C"
