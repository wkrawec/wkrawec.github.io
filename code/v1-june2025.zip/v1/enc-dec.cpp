#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include <rs>

// TODO: Play with these to find optimal EC size based on noise
const int EC_BLOCK_SIZE = 25;
const int PARITY_SIZE = 128;//251;

void encryptStream(std::ifstream& fin, std::ofstream& fout, std::ifstream& fdata, std::ofstream& fpar, int headerIgnore);
void decryptStream(std::ifstream& fin, std::ofstream& fout, std::ifstream& fpar, std::vector<int>& prf, bool useEC, int headerIgnore);

// note if the file is .bmp the program behaves a little differently: It will not encrypt/decryt the bmp header (54 bytes).
// this is done for visualization purposes (so you can view the ciphertext as a bmp for instance)
// this can be disabled by changing the "54" to "0" below (and in decrypt).

void encrypt(const std::string& input, const std::string& output, const std::string& rawdata)
{
  std::ifstream fin, fdata;
  std::ofstream fout, fpar;

  std::string parout("ct.parity");
  
  fin.open(input, std::ios::binary);
  fout.open(output);
  fdata.open(rawdata);
  fpar.open(parout);

  if(input[input.size()-4] == '.'
     && input[input.size()-3] == 'b'
     && input[input.size()-2] == 'm'
     && input[input.size()-1] == 'p')
    encryptStream(fin, fout, fdata, fpar, 54);
  else
    encryptStream(fin, fout, fdata, fpar, 0);
}

void encryptStream(std::ifstream& fin, std::ofstream& fout, std::ifstream& fdata, std::ofstream& fpar, int headerIgnore)
{
  std::cout << "Ignoring header of size " << headerIgnore << " bytes.\n";
  
  int i=0, j=0, w=0;
  
  char c=0;
  uint8_t cp;

  std::vector <uint8_t> data_block;

  ezpwd::RS<255,PARITY_SIZE> rs;

  std::ofstream rawout;
  rawout.open("raw.bmp", std::ios::binary);
  
  while(fin.get(c)){
    cp = 0;
    int p = 1;
    int cd = 0;
    for(int l=0; l<8; ++l){
      int b = (c >> l) & 1; // get bit "i" of this PT byte
      fdata >> i >> j >> w; // read next pad data
      if(w == 1 && headerIgnore <= 0)
	b = 1-b;

      fout << i << "\t" << j << "\t" << b << "\n";

      // error correction on PAD (w):
      if(w == 1)
	cp += p;
      if(b == 1)
	cd += p;
      p = p << 1;
    }
    if(headerIgnore > 0)
      --headerIgnore;

    rawout << (char) cd;

    data_block.push_back(cp);
    if(data_block.size() >= EC_BLOCK_SIZE){
      std::vector <uint8_t> parity;
      rs.encode(data_block, parity);

      //for(int i=0; i<data_block.size(); ++i)
      //std::cout << (int)data_block[i] << "\n";
      
      for(int i=0; i<parity.size(); ++i)
	fpar << (int)parity[i] << "\n";

      data_block = std::vector<uint8_t> ();
    }
  }

  // output final data:
  std::vector <uint8_t> parity;
  rs.encode(data_block, parity);
  
  //for(int i=0; i<data_block.size(); ++i)
  //std::cout << (int)data_block[i] << "\n";
  
  for(int i=0; i<parity.size(); ++i)
    fpar << (int)parity[i] << "\n";


  fin.close();
  fout.close();
  fdata.close();
  fpar.close();
  rawout.close();
}

void decrypt(const std::string& input, const std::string& output, std::vector<int>& prf, bool useEC=true)
{
  
  std::ifstream fin, fpar;
  std::ofstream fout;

  fin.open(input);
  fpar.open("ct.parity");
  fout.open(output, std::ios::binary);

  if(output[input.size()-4] == '.'
     && output[input.size()-3] == 'b'
     && output[input.size()-2] == 'm'
     && output[input.size()-1] == 'p')
    decryptStream(fin, fout, fpar, prf, useEC, 54);
  else
    decryptStream(fin, fout, fpar, prf, useEC, 0);
}

void decryptStream(std::ifstream& fin, std::ofstream& fout, std::ifstream& fpar, std::vector<int>& prf, bool useEC, int ignoreHeader)
{
  if(useEC)
    std::cout << "Decrypting with error correction.\n";
  else
    std::cout << "Decrypting without error correction.\n";

  std::cout << "Ignoring header of size " << ignoreHeader << "bytes.\n";


  int i=0, j=0, ct=0;

  int p = 1;
  //p >> 7;
  uint8_t padbyte = 0;
  int bindex = 0;

  ezpwd::RS<255,PARITY_SIZE> rs;

  std::vector <uint8_t> raw_data_block;
  std::vector <int> ciphertext_block;

  int ctbyte = 0;

  int totalFixed = 0;

  
  while(fin >> i >> j >> ct){
    //ciphertext_block.push_back(ct);
    //    int b = w;
    if(ct == 1)
      ctbyte += p;
    int w = (prf[i] + prf[j])%2;
    
    //if((prf[i] + prf[j])%2 == 1)
    //  b = 1-b;

    if(w == 1){
      padbyte += p;
    }
    p = p << 1;
    bindex ++;
    if(bindex == 8){
      // got one byte
      //fout << (char)c;
      raw_data_block.push_back(padbyte);
      ciphertext_block.push_back(ctbyte);
      padbyte = 0;
      ctbyte = 0;
      bindex = 0;
      p = 1;
    }

    if(raw_data_block.size() >= EC_BLOCK_SIZE){
      // got a EC block, so check parity and correct
      std::vector<uint8_t> parity;
      for(int i=0; i<rs.nroots(); ++i){
	int cp=0;
	fpar >> cp;
	parity.push_back(cp);
      }

      //for(int i=0; i<raw_data_block.size(); ++i)
      //std::cout << (int)raw_data_block[i] << "\n";


      if(useEC){
	int fixed = rs.decode(raw_data_block, parity);
	if(fixed > 0)
	  totalFixed += fixed;
	else if(fixed < 0)
	  std::cout << "ERROR WITH ERROR CORRECTION.\n";
      }


      // now use raw_data_block, which is the EC pad, to decrypt CT
      for(int i=0; i<raw_data_block.size(); ++i){
	int m = raw_data_block[i] ^ ciphertext_block[i];
	if(ignoreHeader >= 0){
	  m = m ^ raw_data_block[i];
	  --ignoreHeader;
	}
	fout << (char) m;
      }
      ciphertext_block = std::vector<int>();
      raw_data_block = std::vector<uint8_t>();
    }
  }

  // now decrypt remaining data:
  std::vector<uint8_t> parity;
  for(int i=0; i<rs.nroots(); ++i){
    int cp=0;
    fpar >> cp;
    parity.push_back(cp);
  }
  
  //for(int i=0; i<raw_data_block.size(); ++i)
  // std::cout << (int)raw_data_block[i] << "\n";
  

  if(useEC){
    int fixed = rs.decode(raw_data_block, parity);
    if(fixed > 0)
      totalFixed += fixed;
    else if(fixed < 0)
      std::cout << "ERROR WITH ERROR CORRECTION.\n";
  }
  
  
  // now use raw_data_block, which is the EC pad, to decrypt CT
  for(int i=0; i<raw_data_block.size(); ++i){
    int m = raw_data_block[i] ^ ciphertext_block[i];
    fout << (char) m;
  }


  std::cout << "done. There were " << totalFixed << " errors that were corrected.\n";
  
  fin.close();
  fout.close();
  fpar.close();
}

void loadPRFData(const std::string& prffile, std::vector <int>& prf)
{
  std::cout << "Loading PRF... ";
  std::ifstream f;

  f.open(prffile);

  int w = 0;
  while(f >> w){
    prf.push_back(w);
  }

  f.close();
  std::cout << "done (" << prf.size() << ").\n";
}

int main(int argc, char** argv)
{
  if(argc < 3){
    std::cout << "usage: [e/d] input output [prfFile if d] [use ec (y/n) if d]\n";
    return 0;
  }

  bool encryptMode = true;
  if(argv[1][0] == 'd')
    encryptMode = false;
  
  std::string input(argv[2]);
  std::string output(argv[3]);
  
  std::string rawdata = "raw-data.txt";

  if(encryptMode)
    encrypt(input, output, rawdata);
  else{
    bool useEC = false;
    if(argv[5][0] == 'y')
      useEC = true;
    
    std::vector <int> prf;
    loadPRFData(argv[4], prf);
    decrypt(input, output, prf, useEC);
  }

  return 0;
}
