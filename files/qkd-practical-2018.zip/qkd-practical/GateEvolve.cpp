/*
GateEvolve.cpp
Written by Walter O. Krawec and Sam A. Markelon
Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include "GateEvolve.h"

// 4 works well for BB84
int MAX_GATES_PER_CS = 4;
//#define MAX_GATES_PER_CS 4

namespace QKD
{
namespace GateGA
{
  void Protocol::applyAttack(std::list<Gate>& gates, quantum::DensityList& rho, int TransitWire)
  {
    if(gates.empty())  // empty list taken to mean Identity op.
      return;

    std::list <Gate>::iterator Iter;
    for(Iter = gates.begin(); Iter != gates.end(); ++Iter){
      int wireIndex = Iter->getSmallestWireIndex(1) + TransitWire;
      int controlIndex = Iter->getSmallestWireIndex(2) + TransitWire;

      switch(Iter->type){
	case Hadamard:
	rho.applyHadamard(wireIndex);
	break;

      case CNOT:
	rho.CNOT(wireIndex, controlIndex);
	break;

      case Rotation:
	rho.applySU2(wireIndex, Iter->attr1, Iter->attr2, Iter->attr3);
	//rho.applyRotation(wireIndex, Iter->attr2);
	//rho.applyRotation(wireIndex, .785398);
	//rho.applyRotation(wireIndex, cos(.93));
	break;

	//case Measurement:
	//rho.measure(wireIndex);
	//break;
      }
    }
  }

  void CS::randomize()
  {
    for(int c=0; c<gates.size(); ++c){
      int numGatesToCreate = 1+(rand()%MAX_GATES_PER_CS);
      for(int i=0; i<numGatesToCreate; ++i){
	Gate g;
	g.type = rand()%MAX_GATE_TYPE;
	// pick a "1" and a "2":
	int w1 = rand()%numWires;
	int w2 = rand()%numWires;
	//std::cout << "W1 = " << w1 << "\nW2 = " << w2 << "\n";
	g.wires[w1] = 1;
	g.wires[w2] = 2;
	
	// and finally add to channel:
	gates[c].push_back(g);
      }
    }
  }

  void CS::crossover(CS& other, CS& child)
  {
    child = other; // make sure stuff is setup

    // treat each channel separately?

    for(int c=0; c<gates.size(); ++c){
      child.gates[c].clear();
      int p1 = 0;
      if(!gates[c].empty())
	p1 = rand()%gates[c].size();  // child = (this_1,...this_p1, other_p1+1, ...)

      std::list <Gate>::iterator Iter;
      if(!gates[c].empty())
	Iter = gates[c].begin();

      std::list <Gate>::iterator Iter2;
      bool OOB = false;  // true if second parent is too small
      if(p1 < other.gates[c].size())
	Iter2 = other.gates[c].begin();
      else
	OOB = true;

      while(p1 > 0){
	child.gates[c].push_back(*Iter);
	++Iter;
	if(!OOB)
	  ++Iter2;

	--p1;
      }
      if(!OOB){
	for(;Iter2 != other.gates[c].end(); ++Iter2)
	  child.gates[c].push_back(*Iter2);
      }
    }
  }

  // setting Pc < Pr greatly helped with BB84 (Nov.22)
  void CS::mutate()
  {
    const int Pc = 20;  // prob. to create new gate
    const int Pr = 30;  // prob. to remove a gate
    const int Pw = 70;  // prob. to mutate wire bit
    const int Pg = 20;  // prob. to mutate gate type
    const int Pa = 80;  // prob. to mutate attr

    // Nov. 22 made this change to apply to all channels instead of one ch.

    for(int c=0; c<gates.size(); ++c){
      if(rand()%100 < Pc){
	// create a new gate, appending to the end
	Gate g;
	g.type = rand()%MAX_GATE_TYPE;
	// pick a "1" and a "2":
	int w1 = rand()%numWires;
	int w2 = rand()%numWires;
	
	g.wires[w1] = 1;
	g.wires[w2] = 2;
	
	// and finally a channel:
	////int c = rand()%gates.size();
	if(gates[c].size() < MAX_GATES_PER_CS/( (0+1) ))
	  gates[c].push_back(g);
      }

      if(rand()%100 < Pr){
	////int c = rand()%gates.size();
	if(!gates[c].empty()){
	  int g = rand()%gates[c].size();
	  std::list <Gate>::iterator Iter=gates[c].begin();
	  while(g > 0){
	    ++Iter;
	    --g;
	  }
	  
	  gates[c].erase(Iter);
	}
      }
    }

    for(int i=0; i<gates.size(); ++i){
      if(gates[i].empty())
	continue;
      std::list <Gate>::iterator Iter;
      for(Iter = gates[i].begin(); Iter != gates[i].end(); ++Iter){
	if(rand()%100 < Pg){
	  Iter->type = rand()%MAX_GATE_TYPE;
	}
	if(rand()%100 < Pw){
	  for(int i=0; i<numWires; ++i)
	    Iter->wires[i] = 0;
	  int w1 = rand()%numWires;
	  int w2 = rand()%numWires;
	  Iter->wires[w1] = 1;
	  Iter->wires[w2] = 2;
	}
	if(rand()%100 < Pa){
	  Iter->attr1 += Iter->randFloat(-.2, .2);
	  if(Iter->attr1 < 0)
	    Iter->attr1 = 0;
	  if(Iter->attr1 > 1)
	    Iter->attr1 = 1;
	  Iter->attr2 += Iter->randFloat(-1, 1);
	  Iter->attr3 += Iter->randFloat(-1, 1);

	  //Iter->attr1 = Iter->randFloat(0, 1);
	  //Iter->attr2 = Iter->randFloat(0, 2*3.1415);
	  //Iter->attr3 = Iter->randFloat(0, 2*3.1415);
	}
      }
    }
  }

  void GA::setupPopulation(Protocol* protocol, int MaxPopulation)
  {
    std::cout << "Creating Initial Population...\n";

    maxPopulation = MaxPopulation;

    population.clear();
    for(int i=0; i<maxPopulation; ++i){
      if(i%10 == 0)
	std::cout << i << "/" << maxPopulation << "\n";
      CS cs;
      cs.create(protocol->numChannels(), protocol->numAttackWires()+1);
      cs.calculateFitness(protocol);

      population.push_back(cs);
    }

    // TIME TEST (Nov. 22)
    /**{
      CS cs;
      cs.create(protocol->numChannels(), protocol->numAttackWires()+1);
      time_t startTime = time(NULL);
      for(int i=0; i<1000; ++i){
	cs.calculateFitness(protocol);
      }
      time_t endTime = time(NULL);
      std::cout << "TOTAL TIME = " << endTime - startTime << "\n\n";
      }**/

    /**std::cout << "BEFORE SORT:\n";
    protocol->printStats(population.begin()->gates);
    population.begin()->print();**/

    population.sort();

    /**std::cout << "AFTER SORT:\n";
    protocol->printStats(population.begin()->gates);
    population.begin()->print();**/
    std::cout << "...done.\n";
  }

  GAOutput GA::evolve(Protocol* protocol, int MaxGenerations, double tol, int HC)
  {
    const int TOURN_SIZE=3;
    const int MUTATION_RATE=80;// 80 was working good for BB85 //25;
    const int ELITE_SIZE = 1;

    double noiseOutput = 1;
    
    std::list <CS> tempPopulation;
    std::list <CS>::iterator Iter1, Iter2;

    for(int iter=0; iter<MaxGenerations; ++iter){
      double avgFit = 0;
      double avgCount = 0;
      std::cout << "Iteration " << iter << ":\n";
      tempPopulation.clear();


      Iter1 = population.begin();
      for(int p=0; p<ELITE_SIZE; ++p){
	tempPopulation.push_back(*Iter1);
	++Iter1;
      }

      for(int p=0; p<maxPopulation-ELITE_SIZE; ++p){
	int parent1 = maxPopulation+1;
	for(int t=0; t<TOURN_SIZE; ++t){
	  int temp = rand()%maxPopulation;
	  if(temp < parent1)
	    parent1 = temp;
	}

	int parent2 = maxPopulation+1;
	for(int t=0; t<TOURN_SIZE; ++t){
	  int temp = rand()%maxPopulation;
	  if(temp < parent2)
	    parent2 = temp;
	}


	Iter1 = population.begin();
	for(int j=0; j<parent1; ++j)
	  ++Iter1;

	Iter2 = population.begin();
	for(int j=0; j<parent2; ++j)
	  ++Iter2;

	CS child;
	Iter1->crossover(*Iter2, child);

	if(rand()%100 < MUTATION_RATE)
	  child.mutate();

	avgFit += child.calculateFitness(protocol);
	avgCount ++;
	tempPopulation.push_back(child);
      }

      tempPopulation.sort();
      // HC:

      if(HC == 1){
	std::cout << "With HC\n";
	for(int i=0; i<100; ++i){
	  CS best = *tempPopulation.begin();
	  best.mutate();
	  best.calculateFitness(protocol);
	  if(best.fitness < tempPopulation.begin()->fitness){
	    tempPopulation.push_back(best);
	  }
	}
	tempPopulation.sort();
      }

      population = tempPopulation;
      std::cout << "\tFitness = " << population.begin()->fitness << "\n";
      std::cout << "\tAvg. Fitness = " << avgFit/avgCount << "\n";
      std::cout << "\tNoise Tol. = " << noiseOutput << "\n\n";

      protocol->printStats(population.begin()->gates);
      double rate = protocol->computeKeyRate(population.begin()->gates);
      if(rate < tol){
	std::vector <double> noise;
	protocol->computeErrorRate(population.begin()->gates, noise);
	double avgNoise = 0;
	for(int i=0; i<noise.size(); ++i)
	  avgNoise += noise[i];
	avgNoise = avgNoise / (double)noise.size();

	if(avgNoise < noiseOutput){
	  noiseOutput = avgNoise;

	  if(noiseOutput < .25){
	    std::ofstream f;
	    f.open("solution.txt");
	    f << "rate = " << rate << "\n";
	    f << "noise = " << avgNoise << "\n";
	    population.begin()->print(f);
	    f.close();
	  }

	}
      }

      //protocol->printStats( (++population.begin())->gates );
    }

    population.begin()->print(std::cout);

    GAOutput out;
    std::vector <double> noise;
    protocol->computeErrorRate(population.begin()->gates, noise);
    out.avgBest = 0;
    for(int i=0; i<noise.size(); ++i)
      out.avgBest += noise[i];
    out.avgBest = out.avgBest / (double)noise.size();

    out.noiseOut = noiseOutput;

    {
      double rate = protocol->computeKeyRate(population.begin()->gates);
      std::vector <double> noise;
      protocol->computeErrorRate(population.begin()->gates, noise);
      double avgNoise = 0;
      for(int i=0; i<noise.size(); ++i)
	avgNoise += noise[i];
      avgNoise = avgNoise / (double)noise.size();
      
      std::ofstream f;
      f.open("solution-output.txt");
      f << "rate = " << rate << "\n";
      f << "noise = " << avgNoise << "\n";
      population.begin()->print(f);
      f.close();
    }

    return out;
 }
}
}
