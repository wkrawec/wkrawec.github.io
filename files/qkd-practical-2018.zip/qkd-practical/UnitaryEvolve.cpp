/*
UnitaryEvolve.cpp
Written by Walter O. Krawec and Sam A. Markelon
Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include "UnitaryEvolve.h"

namespace QKD
{
namespace UnitaryGA
{
  void Protocol::applyAttack(algebra::mat& U, quantum::DensityList& rho, int TransitWire)
  {
    rho.applyOp(U, TransitWire);
  }

  void CS::crossover(CS& other, CS& child)
  {
    child = other; // make sure stuff is setup

    // treat each channel separately?

    for(int c=0; c<chi.size(); ++c){
      int p1 = rand()%chi[c].size();
      for(int i=0; i<chi[c].size(); ++i){
	if(i < p1)
	  child.chi[c][i] = chi[c][i];
	else
	  child.chi[c][i] = other.chi[c][i];
      }

      int p2 = rand()%phi[c].size();
      for(int i=0; i<phi[c].size(); ++i){
	if(i < p2)
	  child.phi[c][i] = phi[c][i];
	else
	  child.phi[c][i] = other.phi[c][i];
      }

      int p3 = rand()%psi[c].size();
      for(int i=0; i<psi[c].size(); ++i){
	if(i < p3)
	  child.psi[c][i] = psi[c][i];
	else
	  child.psi[c][i] = other.psi[c][i];
      }

      if(rand()%100 < 50)
	child.alpha[c][0] = alpha[c][0];
      else
	child.alpha[c][0] = other.alpha[c][0];
    }

    construct();
  }

  // setting Pc < Pr greatly helped with BB84 (Nov.22)
  void CS::mutate()
  {
    int pr = 10; // 10

    for(int c=0; c<chi.size(); ++c){
      for(int i=0; i<chi[c].size(); ++i){
	if(rand()%100 < pr)
	  chi[c][i] += randFloat(-5*3.1415, 5*3.1415);
      }

      for(int i=0; i<phi[c].size(); ++i){
	if(rand()%100 < pr)
	  phi[c][i] += randFloat(-5*3.1415, 5*3.1415);
      }

      for(int i=0; i<psi[c].size(); ++i){
	if(rand()%100 < pr)
	  psi[c][i] += randFloat(-5*3.1415, 5*3.1415);
      }

      if(rand()%100 < pr)
	alpha[c][0] += randFloat(-3.1415, 3.1415);
    }

    construct();
  }

  void GA::setupPopulation(Protocol* protocol, int MaxPopulation)
  {
    std::cout << "Creating Initial Population...\n";

    maxPopulation = MaxPopulation;

    population.clear();
    for(int i=0; i<maxPopulation; ++i){
      if(i%10 == 0)
	std::cout << i << "/" << maxPopulation << "\n";
      CS cs;
      cs.create(protocol->numChannels(), protocol->getAuxDim());
      cs.calculateFitness(protocol);

      population.push_back(cs);
    }

    population.sort();

    std::cout << "...done.\n";
  }

  GAOutput GA::evolve(Protocol* protocol, int MaxGenerations, double tol, int HC)
  {
    const int TOURN_SIZE=3;
    const int MUTATION_RATE=80;// 80 was working good for BB85 //25;
    const int ELITE_SIZE = 1;

    double noiseOutput = 1;
    
    std::list <CS> tempPopulation;
    std::list <CS>::iterator Iter1, Iter2;

    for(int iter=0; iter<MaxGenerations; ++iter){
      double avgFit = 0;
      double avgCount = 0;
      std::cout << "Iteration " << iter << ":\n";
      tempPopulation.clear();


      Iter1 = population.begin();
      for(int p=0; p<ELITE_SIZE; ++p){
	tempPopulation.push_back(*Iter1);
	++Iter1;
      }

      for(int p=0; p<maxPopulation-ELITE_SIZE; ++p){
	int parent1 = maxPopulation+1;
	for(int t=0; t<TOURN_SIZE; ++t){
	  int temp = rand()%maxPopulation;
	  if(temp < parent1)
	    parent1 = temp;
	}

	int parent2 = maxPopulation+1;
	for(int t=0; t<TOURN_SIZE; ++t){
	  int temp = rand()%maxPopulation;
	  if(temp < parent2)
	    parent2 = temp;
	}


	Iter1 = population.begin();
	for(int j=0; j<parent1; ++j)
	  ++Iter1;

	Iter2 = population.begin();
	for(int j=0; j<parent2; ++j)
	  ++Iter2;

	CS child;
	Iter1->crossover(*Iter2, child);

	if(rand()%100 < MUTATION_RATE)
	  child.mutate();

	avgFit += child.calculateFitness(protocol);
	avgCount ++;
	tempPopulation.push_back(child);
      }

      tempPopulation.sort();
      // HC:

      if(HC == 1){
	std::cout << "With HC\n";
	for(int i=0; i<100; ++i){
	  CS best = *tempPopulation.begin();
	  best.mutate();
	  best.calculateFitness(protocol);
	  if(best.fitness < tempPopulation.begin()->fitness){
	    tempPopulation.push_back(best);
	  }
	}

	/*CS currentBest = *tempPopulation.begin();
	for(int i=0; i<100; ++i){
	  CS best = currentBest;
	  best.mutate();
	  best.calculateFitness(protocol);
	  if(best.fitness < currentBest.fitness){
	    std::cout << ".\n";
	    //currentBest = best;
	    tempPopulation.push_back(best);
	  }
	  }*/
	tempPopulation.sort();
      }
      population = tempPopulation;
      std::cout << "\tFitness = " << population.begin()->fitness << "\n";
      std::cout << "\tAvg. Fitness = " << avgFit/avgCount << "\n";
      std::cout << "\tNoise Tol. = " << noiseOutput << "\n\n";

      protocol->printStats(population.begin()->U);
      double rate = protocol->computeKeyRate(population.begin()->U);
      if(rate < tol){
	std::vector <double> noise;
	protocol->computeErrorRate(population.begin()->U, noise);
	double avgNoise = 0;
	for(int i=0; i<noise.size(); ++i)
	  avgNoise += noise[i];
	avgNoise = avgNoise / (double)noise.size();

	if(avgNoise < noiseOutput)
	  noiseOutput = avgNoise;
      }

      //protocol->printStats( (++population.begin())->gates );
    }

    population.begin()->print();

    GAOutput out;
    std::vector <double> noise;
    protocol->computeErrorRate(population.begin()->U, noise);
    out.avgBest = 0;
    for(int i=0; i<noise.size(); ++i)
      out.avgBest += noise[i];
    out.avgBest = out.avgBest / (double)noise.size();

    out.noiseOut = noiseOutput;

    return out;
 }
}
}
