/*
SQKD1-unitary-prac.h
Written by Walter O. Krawec and Sam A. Markelon
Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include "../UnitaryEvolve.h"

namespace QKD
{
namespace UnitaryGA
{

namespace Protocols
{
  class SQKD1prac : public QKD::UnitaryGA::Protocol
  {
  public:
    virtual ~SQKD1prac()
    {
    }

    virtual bool setup()
    {
    }

    virtual int numChannels()
    {
      return 2;
    }

    virtual void printStats(std::vector < algebra::mat >& U)
    {
      double rate = computeKeyRate(U);
      std::vector <double> stats;
      computeErrorRate(U, stats);
      std::cout << "\t\tSQKD:rate=" << rate << ":[";
      double avgNoise = 0;
      for(int i=0; i<stats.size(); ++i){
	avgNoise += stats[i];
	std::cout << stats[i] << ", ";
      }
      std::cout << "avg=" << avgNoise/(double)stats.size();
      std::cout << "]\n";
    }

    virtual double computeKeyRate(std::vector < algebra::mat >& U)
    {
      const int NUM_WIRES=5; // A, B, T, E_guess E_aux1
      const int AUX_DIM = getAuxDim();
      // simulate the channel: A sends |0> or |1>:

      const int A=0;
      const int B=1;
      const int T=2;
      const int Eg = 3;
      const int Eaux=4;

      quantum::DensityList rho;

      setupWires(rho, NUM_WIRES, AUX_DIM); 

      quantum::KetBra kb(NUM_WIRES);
      kb.p = .5;

      rho.density.push_back(kb);
      kb.ket[A] = 1;
      kb.bra[A] = 1;
      kb.ket[T] = 1;
      kb.bra[T] = 1;

      rho.density.push_back(kb);

      // Eve attacks:

      applyAttack(U[0], rho, T);

      // Bob M+R:
      rho.measureAndSave(T, B);

      // Eve attacks again:

      applyAttack(U[1], rho, T);

      // Eve measures:
      for(int i=Eg; i<NUM_WIRES; ++i)
	rho.measure(i);

      for(int i=Eaux; i<NUM_WIRES; ++i)
	rho.trace(i);


      rho.trace(T);

      double ab00 = rho.calculatePr(A, 0, B, 0);
      double ab01 = rho.calculatePr(A, 0, B, 1);
      double ab10 = rho.calculatePr(A, 1, B, 0);
      double ab11 = rho.calculatePr(A, 1, B, 1);


      //std::cout << "STATS: " << ab00 << ", " << ab01 << ", " << ab10 << ", " << ab11 << "\n";
      //rho.print(std::cout);
      //std::cout << "\n\n";

      rho.trace(B);


      algebra::mat M;
      rho.computeDensityMatFast(M);
      double HAE = M.entropy();
      rho.trace(A);
      rho.computeDensityMatFast(M);
      double HE = M.entropy();
      HAE = HAE - HE;

      double HAB = entropy(ab00, ab01, ab10, ab11) - entropy(ab00+ab10);

      //return HAE;
      return HAE - HAB;
    }

    virtual void computeErrorRate(std::vector < algebra::mat >& U, std::vector <double>& errorStats)
    {
      int A=0;
      int B=1;
      int T=2;
      int Eg = 3;
      int Eaux=4;

      const int AUX_DIM = getAuxDim();

      errorStats.resize(3);  // Z and X basis noise
      const int NUM_WIRES=5; // A, B, T, E_guess E_aux1

      /****** Z A->B *******/
      {
	// simulate the channel: A sends |0> or |1>:
	quantum::DensityList rho;

	setupWires(rho, NUM_WIRES, AUX_DIM); 

	quantum::KetBra kb(NUM_WIRES);
	kb.p = .5;
	
	rho.density.push_back(kb);
	kb.ket[A] = 1;
	kb.bra[A] = 1;
	kb.ket[T] = 1;
	kb.bra[T] = 1;
	
	rho.density.push_back(kb);
	
	// Eve attacks:
	
	applyAttack(U[0], rho, T);

	// B measures
	rho.measureAndSave(T, B);

	// E attacks again
	applyAttack(U[1], rho, T);

	// Eve measures:
	for(int i=Eg; i<NUM_WIRES; ++i)
	  rho.measure(i);
	
	
	double p01Z = rho.calculatePr(A, 0, B, 1);
	double p10Z = rho.calculatePr(A, 1, B, 0);

	errorStats[0] = p01Z+p10Z;
      }

      /****** Z B->A *******/
      {
	// simulate the channel: A sends |0> or |1>:
	quantum::DensityList rho;

	setupWires(rho, NUM_WIRES, AUX_DIM); 

	quantum::KetBra kb(NUM_WIRES);
	kb.p = .5;
	
	rho.density.push_back(kb);
	kb.ket[T] = 1;
	kb.bra[T] = 1;
	
	rho.density.push_back(kb);
	
	// Eve attacks:
	
	applyAttack(U[0], rho, T);

	// B measures
	rho.measureAndSave(T, B);

	// E attacks again
	applyAttack(U[1], rho, T);

	// A measures
	rho.measureAndSave(T, A);

	// Eve measures:
	for(int i=Eg; i<NUM_WIRES; ++i)
	  rho.measure(i);
	
	
	double p01Z = rho.calculatePr(A, 0, B, 1);
	double p10Z = rho.calculatePr(A, 1, B, 0);

	errorStats[1] = p01Z+p10Z;
      }

      /****** X A->A *******/
      {
	// simulate the channel: A sends |0> or |1>:
	quantum::DensityList rho;

	setupWires(rho, NUM_WIRES, AUX_DIM); 

	quantum::KetBra kb(NUM_WIRES);
	kb.p = .5;
	
	rho.density.push_back(kb);
	kb.ket[A] = 1;
	kb.bra[A] = 1;
	kb.ket[T] = 1;
	kb.bra[T] = 1;	
	rho.density.push_back(kb);
	
	rho.applyHadamard(T);
	// Eve attacks:
	
	applyAttack(U[0], rho, T);

	// E attacks again
	applyAttack(U[1], rho, T);

	// A measures
	rho.applyHadamard(T);
	rho.measureAndSave(T, B);

	// Eve measures:
	for(int i=Eg; i<NUM_WIRES; ++i)
	  rho.measure(i);
	
	
	double p01Z = rho.calculatePr(A, 0, B, 1);
	double p10Z = rho.calculatePr(A, 1, B, 0);

	errorStats[2] = p01Z+p10Z;
      }

    }
  };
}

}
}
