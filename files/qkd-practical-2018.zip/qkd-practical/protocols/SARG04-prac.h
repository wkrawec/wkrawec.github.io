/*
SARG04-prac.h
Written by Walter O. Krawec and Sam A. Markelon
Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
#include "../GateEvolve.h"

namespace QKD
{
namespace GateGA
{

namespace Protocols
{
  class SARG04prac : public QKD::GateGA::Protocol
  {
  public:
    double saveNoise; // THIS ASSUMES COMPUTE_NOISE IS RUN DIRECTLY AFTER KEYRATE!!!
    virtual ~SARG04prac()
    {
    }

    virtual bool setup()
    {
      saveNoise = 100;
    }

    virtual int numChannels()
    {
      return 1;
    }

    //virtual int numAttackWires()
    //{
     // return 2;
    //}

    virtual void printStats(std::vector < std::list<Gate> >& gates)
    {
      double rate = computeKeyRate(gates);
      std::vector <double> stats;
      computeErrorRate(gates, stats);
      double avgNoise = 0;
      std::cout << "\t\tBB84:rate=" << rate << ":[";
      for(int i=0; i<stats.size(); ++i){
	avgNoise += stats[i];
	std::cout << stats[i] << ", ";
      }
      std::cout << "avg=" << avgNoise/(double)stats.size();
      std::cout << "]\n";
    }

    void computeDensityA(std::vector < std::list<Gate> >& gates, quantum::DensityList& rho)
    {
      const int A = 0;
      const int B = 1;
      const int BGuess = 2;
      const int APub1=3;
      const int APub2 = 4;
      const int T = 5;
      const int E_guess = 6;
      const int E_aux = 7;
      const int NUM_WIRES=E_guess+numAttackWires();

      // simulate the channel: A sends |0> or |+>

      setupWires(rho, NUM_WIRES); 

      quantum::KetBra kb(NUM_WIRES);
      kb.p = .5 * .25;  // .25 since four modes of operation: A, B, C, and D
      rho.density.push_back(kb);

      kb.ket[A] = 1;
      kb.bra[A] = 1;
      kb.ket[T] = 0;
      kb.bra[T] = 0;
      rho.density.push_back(kb);

      algebra::mat H;
      H.create(2);
      H(0,0) = 1.0/sqrt(2.0);
      H(0,1) = 1.0/sqrt(2.0);
      H(1,0) = 1.0/sqrt(2.0);
      H(1,1) = -1.0/sqrt(2.0);

      rho.applyConditionalOp(A, 1, T, H);


      // Eve attacks:

      applyAttack(gates[0], rho, T);

      // Eve measures:
      // comment four lines for full attack:
      for(int i=E_guess; i<NUM_WIRES; ++i)
	rho.measure(i);

      for(int i=E_aux; i<NUM_WIRES; ++i)
	rho.trace(i);


      // Bob measures:
      rho.applyOp(BGuess, H);
      rho.measure(BGuess); // 50/50 Z or X basis

      rho.applyConditionalOp(BGuess, 1, T, H);
      rho.measure(T);

      // now process result
      // (This is something of a hack ATM)
      {
      	std::list <quantum::KetBra>::iterator Iter;

	std::list <quantum::KetBra> newDensity;

	for(Iter=rho.density.begin(); Iter != rho.density.end(); ++Iter){
	  if(Iter->ket[BGuess] == 0 && Iter->ket[T] == 1){
	    Iter->ket[B] = 1;
	    Iter->bra[B] = 1;
	    newDensity.push_back(*Iter);
	  }
	  else if(Iter->ket[BGuess] == 1 && Iter->ket[T] == 1){
	    Iter->ket[B] = 0;
	    Iter->bra[B] = 0;
	    newDensity.push_back(*Iter);
	  }
	}
	rho.density = newDensity;
      }
    }

    void computeDensityB(std::vector < std::list<Gate> >& gates, quantum::DensityList& rho)
    {
      const int A = 0;
      const int B = 1;
      const int BGuess = 2;
      const int APub1=3;
      const int APub2 = 4;
      const int T = 5;
      const int E_guess = 6;
      const int E_aux = 7;
      const int NUM_WIRES=E_guess+numAttackWires();

      // simulate the channel: A sends |0> or |+>


      setupWires(rho, NUM_WIRES); 

      quantum::KetBra kb(NUM_WIRES);
      kb.p = .5 * .25;  // .25 since four modes of operation: A, B, C, and D
      kb.ket[T] = 1;
      kb.bra[T] = 1;

      kb.ket[APub1] = 0;
      kb.ket[APub2] = 1;

      kb.bra[APub1] = kb.ket[APub1];
      kb.bra[APub2] = kb.ket[APub2];
      rho.density.push_back(kb);

      kb.ket[A] = 1;
      kb.bra[A] = 1;
      kb.ket[T] = 1;
      kb.bra[T] = 1;
      rho.density.push_back(kb);

      algebra::mat H;
      H.create(2);
      H(0,0) = 1.0/sqrt(2.0);
      H(0,1) = 1.0/sqrt(2.0);
      H(1,0) = 1.0/sqrt(2.0);
      H(1,1) = -1.0/sqrt(2.0);

      rho.applyConditionalOp(A, 1, T, H);


      // Eve attacks:

      applyAttack(gates[0], rho, T);

      // Eve measures:
      // comment four lines for full attack:
      for(int i=E_guess; i<NUM_WIRES; ++i)
	rho.measure(i);

      for(int i=E_aux; i<NUM_WIRES; ++i)
	rho.trace(i);


      // Bob measures:
      rho.applyOp(BGuess, H);
      rho.measure(BGuess); // 50/50 Z or X basis

      rho.applyConditionalOp(BGuess, 1, T, H);
      rho.measure(T);

      // now process result
      // (This is something of a hack ATM)
      {
      	std::list <quantum::KetBra>::iterator Iter;

	std::list <quantum::KetBra> newDensity;

	for(Iter=rho.density.begin(); Iter != rho.density.end(); ++Iter){
	  if(Iter->ket[BGuess] == 0 && Iter->ket[T] == 0){
	    Iter->ket[B] = 1;
	    Iter->bra[B] = 1;
	    newDensity.push_back(*Iter);
	  }
	  else if(Iter->ket[BGuess] == 1 && Iter->ket[T] == 0){
	    Iter->ket[B] = 0;
	    Iter->bra[B] = 0;
	    newDensity.push_back(*Iter);
	  }
	}
	rho.density = newDensity;
      }
    }


    void computeDensityC(std::vector < std::list<Gate> >& gates, quantum::DensityList& rho)
    {
      const int A = 0;
      const int B = 1;
      const int BGuess = 2;
      const int APub1=3;
      const int APub2 = 4;
      const int T = 5;
      const int E_guess = 6;
      const int E_aux = 7;
      const int NUM_WIRES=E_guess+numAttackWires();

      // simulate the channel: A sends |0> or |+>


      setupWires(rho, NUM_WIRES); 

      quantum::KetBra kb(NUM_WIRES);
      kb.p = .5 * .25;  // .25 since four modes of operation: A, B, C, and D
      kb.ket[T] = 1;
      kb.bra[T] = 1;

      kb.ket[APub1] = 1;
      kb.ket[APub2] = 0;

      kb.bra[APub1] = kb.ket[APub1];
      kb.bra[APub2] = kb.ket[APub2];

      rho.density.push_back(kb);

      kb.ket[A] = 1;
      kb.bra[A] = 1;
      kb.ket[T] = 0;
      kb.bra[T] = 0;
      rho.density.push_back(kb);

      algebra::mat H;
      H.create(2);
      H(0,0) = 1.0/sqrt(2.0);
      H(0,1) = 1.0/sqrt(2.0);
      H(1,0) = 1.0/sqrt(2.0);
      H(1,1) = -1.0/sqrt(2.0);

      rho.applyConditionalOp(A, 1, T, H);


      // Eve attacks:

      applyAttack(gates[0], rho, T);

      // Eve measures:
      // comment four lines for full attack:
      for(int i=E_guess; i<NUM_WIRES; ++i)
	rho.measure(i);

      for(int i=E_aux; i<NUM_WIRES; ++i)
	rho.trace(i);


      // Bob measures:
      rho.applyOp(BGuess, H);
      rho.measure(BGuess); // 50/50 Z or X basis

      rho.applyConditionalOp(BGuess, 1, T, H);
      rho.measure(T);

      // now process result
      // (This is something of a hack ATM)
      {
      	std::list <quantum::KetBra>::iterator Iter;

	std::list <quantum::KetBra> newDensity;

	for(Iter=rho.density.begin(); Iter != rho.density.end(); ++Iter){
	  if(Iter->ket[BGuess] == 0 && Iter->ket[T] == 0){
	    Iter->ket[B] = 1;
	    Iter->bra[B] = 1;
	    newDensity.push_back(*Iter);
	  }
	  else if(Iter->ket[BGuess] == 1 && Iter->ket[T] == 1){
	    Iter->ket[B] = 0;
	    Iter->bra[B] = 0;
	    newDensity.push_back(*Iter);
	  }
	}
	rho.density = newDensity;
      }

    }


    void computeDensityD(std::vector < std::list<Gate> >& gates, quantum::DensityList& rho)
    {
      const int A = 0;
      const int B = 1;
      const int BGuess = 2;
      const int APub1=3;
      const int APub2 = 4;
      const int T = 5;
      const int E_guess = 6;
      const int E_aux = 7;
      const int NUM_WIRES=E_guess+numAttackWires();

      // simulate the channel: A sends |0> or |+>


      setupWires(rho, NUM_WIRES); 

      quantum::KetBra kb(NUM_WIRES);
      kb.p = .5 * .25;  // .25 since four modes of operation: A, B, C, and D

      kb.ket[APub1] = 1;
      kb.ket[APub2] = 1;

      kb.bra[APub1] = kb.ket[APub1];
      kb.bra[APub2] = kb.ket[APub2];

      rho.density.push_back(kb);

      kb.ket[A] = 1;
      kb.bra[A] = 1;
      kb.ket[T] = 1;
      kb.bra[T] = 1;
      rho.density.push_back(kb);

      algebra::mat H;
      H.create(2);
      H(0,0) = 1.0/sqrt(2.0);
      H(0,1) = 1.0/sqrt(2.0);
      H(1,0) = 1.0/sqrt(2.0);
      H(1,1) = -1.0/sqrt(2.0);

      rho.applyConditionalOp(A, 1, T, H);


      // Eve attacks:

      applyAttack(gates[0], rho, T);

      // Eve measures:
      // comment four lines for full attack:
      for(int i=E_guess; i<NUM_WIRES; ++i)
	rho.measure(i);

      for(int i=E_aux; i<NUM_WIRES; ++i)
	rho.trace(i);


      // Bob measures:
      rho.applyOp(BGuess, H);
      rho.measure(BGuess); // 50/50 Z or X basis

      rho.applyConditionalOp(BGuess, 1, T, H);
      rho.measure(T);

      // now process result
      // (This is something of a hack ATM)
      {
      	std::list <quantum::KetBra>::iterator Iter;

	std::list <quantum::KetBra> newDensity;

	for(Iter=rho.density.begin(); Iter != rho.density.end(); ++Iter){
	  if(Iter->ket[BGuess] == 0 && Iter->ket[T] == 1){
	    Iter->ket[B] = 1;
	    Iter->bra[B] = 1;
	    newDensity.push_back(*Iter);
	  }
	  else if(Iter->ket[BGuess] == 1 && Iter->ket[T] == 0){
	    Iter->ket[B] = 0;
	    Iter->bra[B] = 0;
	    newDensity.push_back(*Iter);
	  }
	}
	rho.density = newDensity;
      }
    }


    virtual double computeKeyRate(std::vector < std::list<Gate> >& gates)
    {
      const int A = 0;
      const int B = 1;
      const int BGuess = 2;
      const int APub1=3;
      const int APub2 = 4;
      const int T = 5;
      const int E_guess = 6;
      const int E_aux = 7;
      const int NUM_WIRES=E_guess+numAttackWires();

      // simulate the channel: A sends |0> or |->

      quantum::DensityList rho, rhoA, rhoB, rhoC, rhoD;

      computeDensityA(gates, rhoA);
      computeDensityB(gates, rhoB);
      computeDensityC(gates, rhoC);
      computeDensityD(gates, rhoD);



      setupWires(rho, NUM_WIRES); 

      std::list <quantum::KetBra>::iterator Iter;

      std::list <quantum::KetBra> newDensity;

      for(Iter=rhoA.density.begin(); Iter != rhoA.density.end(); ++Iter)
	rho.density.push_back(*Iter);
      for(Iter=rhoB.density.begin(); Iter != rhoB.density.end(); ++Iter)
	rho.density.push_back(*Iter);
      for(Iter=rhoC.density.begin(); Iter != rhoC.density.end(); ++Iter)
	rho.density.push_back(*Iter);
      for(Iter=rhoD.density.begin(); Iter != rhoD.density.end(); ++Iter)
	rho.density.push_back(*Iter);

      rho.trace(T);
      rho.trace(BGuess);

      double ab00 = rho.calculatePr(0, 0, 1, 0);
      double ab01 = rho.calculatePr(0, 0, 1, 1);
      double ab10 = rho.calculatePr(0, 1, 1, 0);
      double ab11 = rho.calculatePr(0, 1, 1, 1);

      /*std::cout << "AB00 = " << ab00 << "\n";
      std::cout << "AB10 = " << ab10 << "\n";
      std::cout << "AB01 = " << ab01 << "\n";
      std::cout << "AB11 = " << ab11 << "\n\n";*/

      saveNoise = ab01+ab10;

      double sum = ab00+ab01+ab10+ab11;
      if(fabs(sum-1) > .000001)
	std::cout << "ERROR - SUM != 1\n";


      //rho.print(std::cout);
      //std::cout << "\n\n";

      rho.trace(B);


      // E aux not used (opt. measure these instead)
      //for(int i=5; i<NUM_WIRES; ++i)
      //rho.trace(i);
      //rho.print(std::cout);


      algebra::mat M;
      rho.computeDensityMatFast(M);
      double HAE = M.entropy();
      rho.trace(A);
      rho.computeDensityMatFast(M);
      double HE = M.entropy();
      HAE = HAE - HE;

      double HAB = entropy(ab00, ab01, ab10, ab11) - entropy(ab00+ab10);

      return HAE - HAB;
    }

    virtual void computeErrorRate(std::vector < std::list<Gate> >& gates, std::vector <double>& errorStats)
    {
      errorStats.resize(1);  // Z and X basis noise
      errorStats[0] = saveNoise;
      return;
      const int NUM_WIRES=3+numAttackWires(); // A, B, T, E_guess E_aux1

      /****** Z *******/
      {
	// simulate the channel: A sends |0> or |1>:
	quantum::DensityList rho;

	setupWires(rho, NUM_WIRES); 

	quantum::KetBra kb(NUM_WIRES);
	kb.p = .5;
	
	rho.density.push_back(kb);
	kb.ket[0] = 1;
	kb.bra[0] = 1;
	kb.ket[2] = 1;
	kb.bra[2] = 1;
	
	rho.density.push_back(kb);
	
	// Eve attacks:
	
	applyAttack(gates[0], rho, 2);

	// Eve measures:
	for(int i=3; i<NUM_WIRES; ++i)
	  rho.measure(i);
	
	// Bob measures:
	rho.measureAndSave(2,1);
	
	double p01Z = rho.calculatePr(0, 0, 1, 1);
	double p10Z = rho.calculatePr(0, 1, 1, 0);

	//errorStats[0] = p01Z+p10Z;
      }

      /****** X *******/
      {
	// simulate the channel: A sends |0> or |1>:
	quantum::DensityList rho;

	setupWires(rho, NUM_WIRES); 

	quantum::KetBra kb(NUM_WIRES);
	kb.p = .5;
	
	rho.density.push_back(kb);
	kb.ket[0] = 1;
	kb.bra[0] = 1;
	kb.ket[2] = 1;
	kb.bra[2] = 1;
	
	rho.density.push_back(kb);

	rho.applyHadamard(2);
	
	// Eve attacks:
	
	applyAttack(gates[0], rho, 2);

	// Eve measures:
	for(int i=3; i<NUM_WIRES; ++i)
	  rho.measure(i);
	
	// Bob measures:
	rho.applyHadamard(2);
	rho.measureAndSave(2,1);
	
	double p01X = rho.calculatePr(0, 0, 1, 1);
	double p10X = rho.calculatePr(0, 1, 1, 0);

	//errorStats[1] = p01X+p10X;
      }


      /****** RAW KEY ******/
      {
	const int A = 0;
	const int B = 1;
	const int BGuess = 2;
	const int T = 3;
	const int E_guess = 4;
	const int E_aux = 5;
	const int NUM_WIRES=E_guess+numAttackWires(); // A, B, T, E_guess E_aux1
	// simulate the channel: A sends |0> or |->
	
	quantum::DensityList rho;
	
	setupWires(rho, NUM_WIRES); 
	
	quantum::KetBra kb(NUM_WIRES);
	kb.p = .5;
	rho.density.push_back(kb);
	
	kb.ket[A] = 1;
	kb.bra[A] = 1;
	kb.ket[T] = 1;
	kb.bra[T] = 1;
	rho.density.push_back(kb);
	
	algebra::mat H;
	H.create(2);
	H(0,0) = 1.0/sqrt(2.0);
	H(0,1) = 1.0/sqrt(2.0);
	H(1,0) = 1.0/sqrt(2.0);
	H(1,1) = -1.0/sqrt(2.0);
	
	rho.applyConditionalOp(A, 1, T, H); // change |1> to |->
	
	
	// Eve attacks:
	
	applyAttack(gates[0], rho, T);
	
	// Eve measures:
	// comment four lines for full attack:
	for(int i=E_guess; i<NUM_WIRES; ++i)
	  rho.measure(i);
	
	for(int i=E_aux; i<NUM_WIRES; ++i)
	  rho.trace(i);
	
	// Bob measures:
	rho.applyOp(BGuess, H);
	rho.measure(BGuess); // 50/50 Z or X basis

	rho.applyConditionalOp(BGuess, 1, T, H);
	rho.measureAndSave(T,B);
	
	// now discard all kb's where BGuess = B:
	// (This is something of a hack ATM
	{
	  std::list <quantum::KetBra>::iterator Iter;
	  
	  std::list <quantum::KetBra> newDensity;
	  Complex one=1;
	  for(Iter=rho.density.begin(); Iter != rho.density.end(); ++Iter){
	    if(Iter->ket[B] != Iter->ket[BGuess])
	      newDensity.push_back(*Iter);
	  }
	  
	  rho.density = newDensity;
	}
	
	rho.trace(T);
	rho.trace(BGuess);
	
	double ab01 = rho.calculatePr(0, 0, 1, 1);
	double ab10 = rho.calculatePr(0, 1, 1, 0);

	errorStats[0] = ab01+ab10;
      }
    }
  };
}

}
}
