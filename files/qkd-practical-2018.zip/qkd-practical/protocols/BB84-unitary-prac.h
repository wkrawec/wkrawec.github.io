
/*
BB84-unitary-prac-prac.h
Written by Walter O. Krawec and Sam A. Markelon
Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include "../GateEvolve.h"

namespace QKD
{
namespace UnitaryGA
{

namespace Protocols
{
  class BB84prac : public QKD::UnitaryGA::Protocol
  {
  public:
    virtual ~BB84prac()
    {
    }

    virtual bool setup()
    {
    }

    virtual int numChannels()
    {
      return 1;
    }

    virtual void printStats(std::vector < algebra::mat >& U)
    {
      double rate = computeKeyRate(U);
      std::vector <double> stats;
      computeErrorRate(U, stats);
      double avgNoise = 0;
      std::cout << "\t\tBB84:rate=" << rate << ":[";
      for(int i=0; i<stats.size(); ++i){
	avgNoise += stats[i];
	std::cout << stats[i] << ", ";
      }
      std::cout << "avg=" << avgNoise/(double)stats.size();
      std::cout << "]\n";
    }

    virtual double computeKeyRate(std::vector < algebra::mat >& U)
    {
      const int NUM_WIRES=6; // A, B, Pub, T, E_guess E_aux1
      const int AUX_DIM = getAuxDim();
      // simulate the channel: A sends |0> or |1> or |+> or |->:

      quantum::DensityList rho;

      setupWires(rho, NUM_WIRES, AUX_DIM); 

      quantum::KetBra kb(NUM_WIRES);
      kb.p = .25;
      rho.density.push_back(kb);

      kb.ket[0] = 1;
      kb.bra[0] = 1;
      kb.ket[3] = 1;
      kb.bra[3] = 1;
      rho.density.push_back(kb);

      kb.ket[0] = 0;
      kb.bra[0] = 0;
      kb.ket[2] = 1;
      kb.bra[2] = 1;
      kb.ket[3] = 0;
      kb.bra[3] = 0;
      rho.density.push_back(kb);


      kb.ket[0] = 1;
      kb.bra[0] = 1;
      kb.ket[2] = 1;
      kb.bra[2] = 1;
      kb.ket[3] = 1;
      kb.bra[3] = 1;
      rho.density.push_back(kb);

      algebra::mat H;
      H.create(2);
      H(0,0) = 1.0/sqrt(2.0);
      H(0,1) = 1.0/sqrt(2.0);
      H(1,0) = 1.0/sqrt(2.0);
      H(1,1) = -1.0/sqrt(2.0);
      rho.applyConditionalOp(2, 1, 3, H);


      // Eve attacks:

      applyAttack(U[0], rho, 3);

      // Eve measures:
      // comment four lines for full attack:
      for(int i=4; i<NUM_WIRES; ++i)
	rho.measure(i);

      for(int i=5; i<NUM_WIRES; ++i)
	rho.trace(i);

      // Bob measures:
      rho.applyConditionalOp(2, 1, 3, H);
      rho.measureAndSave(3,1);
      rho.trace(3);

      double ab00 = rho.calculatePr(0, 0, 1, 0);
      double ab01 = rho.calculatePr(0, 0, 1, 1);
      double ab10 = rho.calculatePr(0, 1, 1, 0);
      double ab11 = rho.calculatePr(0, 1, 1, 1);


      rho.trace(1);


      algebra::mat M;
      rho.computeDensityMatFast(M);
      double HAE = M.entropy();
      rho.trace(0);
      rho.computeDensityMatFast(M);
      double HE = M.entropy();
      HAE = HAE - HE;

      double HAB = entropy(ab00, ab01, ab10, ab11) - entropy(ab00+ab10);

      return HAE - HAB;
    }

    virtual void computeErrorRate(std::vector < algebra::mat >& U, std::vector <double>& errorStats)
    {
      const int AUX_DIM = getAuxDim();
      errorStats.resize(1);  // Z and X basis noise
      const int NUM_WIRES=6; // A, B, Pub, T, E_guess E_aux1
      // simulate the channel: A sends |0> or |1> or |+> or |->:

      quantum::DensityList rho;

      setupWires(rho, NUM_WIRES, AUX_DIM); 

      quantum::KetBra kb(NUM_WIRES);
      kb.p = .25;
      rho.density.push_back(kb);

      kb.ket[0] = 1;
      kb.bra[0] = 1;
      kb.ket[3] = 1;
      kb.bra[3] = 1;
      rho.density.push_back(kb);

      kb.ket[0] = 0;
      kb.bra[0] = 0;
      kb.ket[2] = 1;
      kb.bra[2] = 1;
      kb.ket[3] = 0;
      kb.bra[3] = 0;
      rho.density.push_back(kb);


      kb.ket[0] = 1;
      kb.bra[0] = 1;
      kb.ket[2] = 1;
      kb.bra[2] = 1;
      kb.ket[3] = 1;
      kb.bra[3] = 1;
      rho.density.push_back(kb);

      algebra::mat H;
      H.create(2);
      H(0,0) = 1.0/sqrt(2.0);
      H(0,1) = 1.0/sqrt(2.0);
      H(1,0) = 1.0/sqrt(2.0);
      H(1,1) = -1.0/sqrt(2.0);
      rho.applyConditionalOp(2, 1, 3, H);


      // Eve attacks:

      applyAttack(U[0], rho, 3);

      // Eve measures:
      // comment four lines for full attack:
      for(int i=4; i<NUM_WIRES; ++i)
	rho.measure(i);

      for(int i=5; i<NUM_WIRES; ++i)
	rho.trace(i);

      // Bob measures:
      rho.applyConditionalOp(2, 1, 3, H);
      rho.measureAndSave(3,1);
      rho.trace(3);

      double ab00 = rho.calculatePr(0, 0, 1, 0);
      double ab01 = rho.calculatePr(0, 0, 1, 1);
      double ab10 = rho.calculatePr(0, 1, 1, 0);
      double ab11 = rho.calculatePr(0, 1, 1, 1);
      errorStats[0] = ab01+ab10;
    }

  };
}

}
}
