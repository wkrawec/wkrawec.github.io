/*
UnitaryEvolve.h
Written by Walter O. Krawec and Sam A. Markelon
Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#pragma once

#include <vector>
#include <list>
#include <math.h>

#include "Quantum/Quantum.h"

extern int MAX_GATES_PER_CS;

namespace QKD
{
namespace UnitaryGA
{
  class Protocol
  {
  public:
    virtual ~Protocol()
    {
    }

    virtual bool setup()=0;
    virtual int numChannels()=0;  // return the number of quantum channels used
    virtual void setAuxDim(int a){auxDim = a;}; // return number of E's attack wires
    virtual int getAuxDim() {return auxDim;};
    virtual double computeKeyRate(std::vector < algebra::mat >& U)=0;
    virtual void computeErrorRate(std::vector < algebra::mat >& U, std::vector <double>& errorStats)=0;
    virtual void printStats(std::vector < algebra::mat >& U)=0;

    virtual void applyAttack(algebra::mat& U, quantum::DensityList& rho, int TransitWire);

    virtual void setupWires(quantum::DensityList& rho, int numWires, int AuxDim)
    {
      auxDim = AuxDim;
      for(int i=0; i<numWires-1; ++i)
	rho.dimension.push_back(2);
      rho.dimension.push_back(auxDim);
    }

    virtual double SafeLog(double x)
    {
      if(x < 0.00000001)
	return 0;
      return log(x) / log(2.0);
    }
    virtual double entropy(double x)
    {
      return -x*SafeLog(x) - (1-x)*SafeLog(1-x);
    }
    virtual double entropy(double a, double b, double c, double d)
    {
      return -a*SafeLog(a) - b*SafeLog(b) - c*SafeLog(c) - d*SafeLog(d);
    }

  private:
    int auxDim;
  };

  // a CS is a description of a unitary operator
  struct CS
  {
    void print()
    {
    }

    std::vector < std::vector <double> > phi, psi, chi, alpha;

    std::vector < algebra::mat > U;

    void construct()
    {
      for(int i=0; i<U.size(); ++i)
	U[i].random_unitary(phi[i], psi[i], chi[i], alpha[i][0]);
    }

    void create(int NumAttacks, int AuxSize) // auxsize is E's memory dimension
    {
      phi.resize(NumAttacks);
      psi.resize(NumAttacks);
      chi.resize(NumAttacks);
      alpha.resize(NumAttacks);
      U.resize(NumAttacks);

      int n = 4*AuxSize;
      int N = n*n;
      N = n*(n-1)/2+1;
      for(int i=0; i<NumAttacks; ++i){
	chi[i].resize(n);
	psi[i].resize(N);
	phi[i].resize(N);
	alpha[i].resize(1);
      }

      auxSize = AuxSize;
      fitness = 0;
      randomize();

      construct();
    }

    double randFloat(double small, double large)
    {
      int r = rand();
      double r2 = r;
      r2 = r2 / (double)(RAND_MAX);

      return r2*(large-small)+small;
    }

    void randomize()
    {
      for(int i=0; i<chi.size();++i){
	for(int j=0; j<chi[i].size(); ++j)
	  chi[i][j] = randFloat(0,2*3.1415);
	for(int j=0; j<phi[i].size(); ++j)
	  phi[i][j] = randFloat(0,2*3.1415);
	for(int j=0; j<psi[i].size(); ++j)
	  psi[i][j] = randFloat(0,2*3.1415);

	for(int j=0; j<alpha[i].size(); ++j)
	  alpha[i][j] = randFloat(0,2*3.1415);
      }

      construct();
    }

    void mutate();
    void crossover(CS& other, CS& child);

    double calculateFitness(Protocol* protocol)
    {
      double targetNoise = 0.2/1.5; // 15 for BB84
      double targetRate = -0.02;
      double rate = protocol->computeKeyRate(U);

      std::vector <double> noise;
      protocol->computeErrorRate(U, noise);

      double err = 0;
      double maxNoise = -1;
      double avgNoise = 0;
      double avgNoiseCount = 0;
      for(int i=0; i<noise.size(); ++i){
	if(fabs(noise[i]-targetNoise) > maxNoise)
	  maxNoise = fabs(noise[i]-targetNoise);
	err += ((noise[i]-targetNoise)*(noise[i]-targetNoise));
	avgNoise += noise[i];
	avgNoiseCount += 1.0;
      }

      avgNoise = avgNoise / avgNoiseCount;

      avgNoise = avgNoise - targetNoise;
      // Nov. 23: this seems to work well for BB84 when tr = -.1, tn = 0
      double Pr = .75; // .55 for bb84biased
      double Pe = (1-Pr);
      //fitness = Pr*(rate + .01)*(rate + .01) + Pe*err;
      //fitness = Pr*(rate + .05)*(rate + .05) + Pe*maxNoise*maxNoise;
      fitness = Pr*(rate - targetRate)*(rate - targetRate) + Pe*avgNoise*avgNoise + Pe*maxNoise*maxNoise;


      Pr = .55; // .55 for bb84biased
      Pe = (1-Pr);
      fitness = Pr*(rate - targetRate)*(rate - targetRate) + Pe*avgNoise*avgNoise;

      //fitness += .1*fabs(noise[0] - noise[1]);

      return fitness;
    }

    bool operator< (const CS& other)
    {
      if(fitness < other.fitness)
	return true;
      return false;
    }

    int auxSize;
    double fitness;
  };

  struct GAOutput
  {
    double avgBest;
    double noiseOut;
  };

  class GA
  {
  public:
    void setupPopulation(Protocol* protocol, int MaxPopulation);
    GAOutput evolve(Protocol* protocol, int MaxGenerations, double tol, int HC);

  private:
    int maxPopulation;
    std::list <CS> population;
  };
}
}
