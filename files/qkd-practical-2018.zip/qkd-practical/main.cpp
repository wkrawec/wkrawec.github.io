/*
main.cpp
Written by Walter O. Krawec and Sam A. Markelon
Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include <iostream>
#include <vector>
#include <list>
#include <time.h>

#include "Quantum/Quantum.h"
#include "Quantum/Algebra.h"
#include "GateEvolve.h"
#include "UnitaryEvolve.h"

#include "protocols/BB84-prac.h"
#include "protocols/SQKD1-prac.h"
#include "protocols/BB84-full-prac.h"
#include "protocols/B92-prac.h"
#include "protocols/SARG04-prac.h"

#include "protocols/BB84-unitary-prac.h"
#include "protocols/BB84-full-unitary-prac.h"
#include "protocols/SARG04-unitary-prac.h"
#include "protocols/SQKD1-unitary-prac.h"
#include "protocols/B92-unitary-prac.h"

void testProtocol()
{
  QKD::GateGA::Protocols::BB84prac bb84;

  bb84.setNumAttackWires(3);

  std::vector < std::list <QKD::GateGA::Gate> > gates;
  gates.resize(bb84.numChannels());

  {
    QKD::GateGA::Gate g;
    g.type = 1;
    g.attr1 = 0.961581;
    g.attr2 = 0.0769829;
    g.attr3 = 0.0719372;
    g.wires[1] = 1;
    gates[0].push_back(g);
  }

  {
    QKD::GateGA::Gate g;
    g.type = 0;
    g.wires[0] = 1;
    g.wires[1] = 2;
    gates[0].push_back(g);
  }
  {
    QKD::GateGA::Gate g;
    g.type = QKD::GateGA::CNOT;
    g.wires[0] = 1;
    g.wires[1] = 2;
    //gates[0].push_back(g);
  }
  {
    QKD::GateGA::Gate g;

    g.wires[1] = 1;
    //gates[0].push_back(g);
  }
  {
    QKD::GateGA::Gate g;
    g.type = QKD::GateGA::Rotation;
    g.wires[0] = 1;
    g.attr1 = cos(3.1415/8)*cos(3.1415/8);
    g.attr2 = 0;
    g.attr3 = 0;//3.1415;
    //gates[0].push_back(g);
  }



  std::cout << "key rate = " << bb84.computeKeyRate(gates) << "\n";

  std::vector <double> stats;
  bb84.computeErrorRate_old(gates, stats);
  for(int i=0; i<stats.size(); ++i){
    std::cout << "Noise[" << i << "] = " << stats[i] << "\n";
  }
}

void printUsage()
{
  std::cout << "Usage: verify [protocol-id] [data-file-out] [tolerance] [#trials] [#wires] [#max-gates] [HC] [GATE]\n";
    std::cout << "\tprotocol-id=0: BB84\n";
    std::cout << "\tprotocol-id=1: six-state BB84\n";
    std::cout << "\tprotocol-id=2: B92\n";
    std::cout << "\tprotocol-id=3: SARG04\n";
    std::cout << "\tprotocol-id=4: SQKD-1\n";

    std::cout << "\tHC=0/1: 0=no hill climbing; 1=use hill climbing\n";
    std::cout << "\tGATE=0/1: 0=use unitary; 1 = use gate solution\n";
    std::cout << "\t\tNOTE: If Gate=0, then #wires = dim(Eaux) and #max-gates is ignored.\n";

    std::cout << "\n";
}

void testUnitary()
{
QKD::UnitaryGA::Protocols::SQKD1prac p;

  p.setAuxDim(1);

  QKD::UnitaryGA::GA ga;

  ga.setupPopulation(&p, 100);
  ga.evolve(&p, 1000, 0.005, 1);
}

int main(int argc, char** argv)
{
  //testProtocol();
  //return 0;
  srand(time(NULL));
  //testUnitary();
  //return 0;
  if(argc != 9){
    printUsage();
    return 0;
  }

  int protocol_id = atoi(argv[1]);
  const char* filename = argv[2];
  double tol = atof(argv[3]);
  int numTrials = atoi(argv[4]);
  int numWires = atoi(argv[5]);
  int maxGates = atoi(argv[6]);

  int HC = atoi(argv[7]);
  int gateSolution = atoi(argv[8]);


  std::ofstream f;
  f.open(filename);
  for(int i=0; i<argc; ++i)
    f << argv[i] << " ";
  f << "\n";

  f << "First column = noise tolerance found\n";

  f.close();


  try{
    for(int trial=0; trial < numTrials; ++trial){

      if(gateSolution==0){
	std::cout << "UNITARY MODE\n";
	QKD::UnitaryGA::Protocol* p;
	switch(protocol_id){
	case 0:
	  p = new QKD::UnitaryGA::Protocols::BB84prac;
	  break;
	case 1:
	  p = new QKD::UnitaryGA::Protocols::BB84Fullprac;
	  break;
	case 2:
	  p = new QKD::UnitaryGA::Protocols::B92prac;
	  break;
	case 3:
	  p = new QKD::UnitaryGA::Protocols::SARG04prac;
	  break;
	case 4:
	  p = new QKD::UnitaryGA::Protocols::SQKD1prac;
	  break;
	  
	default:
	  throw std::string("Error - illegal protocol type\n");
	}
	
	p->setAuxDim(numWires);
      
	QKD::UnitaryGA::GA ga;
	ga.setupPopulation(p, 100);
	QKD::UnitaryGA::GAOutput out = ga.evolve(p, 1000, tol, HC);
      
	if(out.noiseOut < .8){ // if larger, then test failed to converge
	  f.open(filename, std::ios_base::app);
	  f << out.noiseOut << "\t" << out.avgBest << "\n";
	  f.close();
	}
	
	delete p;
      }
      else if(gateSolution==1){
	QKD::GateGA::Protocol* p;
	switch(protocol_id){
	case 0:
	  p = new QKD::GateGA::Protocols::BB84prac;
	  break;
	case 1:
	  p = new QKD::GateGA::Protocols::BB84Fullprac;
	  break;
	case 2:
	  p = new QKD::GateGA::Protocols::B92prac;
	  break;
	case 3:
	  p = new QKD::GateGA::Protocols::SARG04prac;
	  break;
	case 4:
	  p = new QKD::GateGA::Protocols::SQKD1prac;
	  break;
	  
	default:
	  throw std::string("Error - illegal protocol type\n");
	}
	
	p->setNumAttackWires(numWires);
	MAX_GATES_PER_CS = maxGates;
      
	QKD::GateGA::GA ga;
	ga.setupPopulation(p, 100);
	QKD::GateGA::GAOutput out = ga.evolve(p, 100, tol, HC);
      
	if(out.noiseOut < .8){ // if larger, then test failed to converge
	  f.open(filename, std::ios_base::app);
	  f << out.noiseOut << "\t" << out.avgBest << "\n";
	  f.close();
	}
	
	delete p;
      }
    }
  } catch(std::string& e){
    std::cout << "Error: " << e << "\n";
  }
  return 0;
}
