/*
GateEvolve.h
Written by Walter O. Krawec and Sam A. Markelon
Copyright (c) 2018

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#pragma once

#include <vector>
#include <list>
#include <math.h>

#include "Quantum/Quantum.h"

extern int MAX_GATES_PER_CS;

namespace QKD
{
namespace GateGA
{
  // some constants:
  enum
  {
    MAX_WIRES = 10
  };

  enum GateType
  {
    CNOT=0,
    Rotation,
    Hadamard,

    //Measurement,

    MAX_GATE_TYPE     // make sure this is last!
  };

  struct Gate
  {
    Gate()
    {
      attr1 = randFloat(0,1);
      attr2 = randFloat(0,2*3.1415);
      attr3 = randFloat(0,2*3.1415);
      for(int i=0; i<MAX_WIRES; ++i)
	wires[i] = 0;
    }
    int type;     // will be 0 - MAX_GATE_TYPE
    double attr1; // an attribute in [0,1]
    double attr2; // an attribute in [0,2Pi]
    double attr3; // an attribute in [0,2Pi]
    char wires[MAX_WIRES];  // smallest index that is "1" determines wire for operation; others are optional
                            // e.g., second smallest is control for CNOT

    double randFloat(double small, double big)
    {
      int r = rand()%RAND_MAX;
      double r2 = r;
      r2 = r2 / (double)RAND_MAX;

      return (big-small)*r2 + small;
    }

    int getIthSmallestIndex(int count)  // returns i'th smallest index (i=0,1,2...) where "1" shows up in "wires"
    {
      for(int i=0; i<MAX_WIRES; ++i){
	if(wires[i] == 1)
	  --count;
	if(count < 0)
	  return i;
      }
      return 0;
    }

    int getSmallestWireIndex(int value)
    {
      for(int i=0; i<MAX_WIRES; ++i){
	if(wires[i] == value)
	  return i;
      }
      return 0;
    }

  };

  class Protocol
  {
  public:
    virtual ~Protocol()
    {
    }

    virtual bool setup()=0;
    virtual int numChannels()=0;  // return the number of quantum channels used
    virtual int numAttackWires(){return numATKWires;}; // return number of E's attack wires
    virtual void setNumAttackWires(int num){numATKWires = num;};
    virtual double computeKeyRate(std::vector < std::list<Gate> >& gates)=0;
    virtual void computeErrorRate(std::vector < std::list<Gate> >& gates, std::vector <double>& errorStats)=0;
    virtual void printStats(std::vector < std::list<Gate> >& gates)=0;

    virtual void applyAttack(std::list <Gate>& gates, quantum::DensityList& rho, int TransitWire);

    virtual void setupWires(quantum::DensityList& rho, int numWires)
    {
      for(int i=0; i<numWires; ++i)
	rho.dimension.push_back(2);
    }

    virtual double SafeLog(double x)
    {
      if(x < 0.00000001)
	return 0;
      return log(x) / log(2.0);
    }
    virtual double entropy(double x)
    {
      return -x*SafeLog(x) - (1-x)*SafeLog(1-x);
    }
    virtual double entropy(double a, double b, double c, double d)
    {
      return -a*SafeLog(a) - b*SafeLog(b) - c*SafeLog(c) - d*SafeLog(d);
    }

  private:
    int numATKWires;
  };

  // a CS is a list of "gates"
  struct CS
  {
  void print(std::ostream& f)
  {
    std::list <Gate>::iterator Iter;
    for(int g=0; g<gates.size(); ++g){
      int count=0;
      f << "\n\nCHANNEL " << g << ":\n";
      for(Iter = gates[g].begin(); Iter != gates[g].end(); ++Iter){
	f << "GATE " << count << " = \n";
	f << "\tType = " << Iter->type << "\n";
	f << "\tAttr1 = " << Iter->attr1 << "\n";
	f << "\tAttr2 = " << Iter->attr2 << "\n";
	f << "\tAttr3 = " << Iter->attr3 << "\n";
	
	int wireIndex = Iter->getSmallestWireIndex(1);
	int controlIndex = Iter->getSmallestWireIndex(2);
	
	f << "\twire = " << wireIndex << "\n";
	f << "\tctrl = " << controlIndex << "\n\n";
	++count;
      }
    }
  }

    std::vector < std::list <Gate> > gates;  // gates[i] if for the i'th attack on n-way channel

    void create(int NumAttacks, int NumWires)  // NumWires = T + Eg + Eaux
    {
      gates.resize(NumAttacks);
      numWires = NumWires;
      fitness = 0;
      randomize();
    }

    void randomize();

    void mutate();
    void crossover(CS& other, CS& child);

    double calculateFitness(Protocol* protocol)
    {
      double targetNoise = 0.0;
      double targetRate = -0.02;
      double rate = protocol->computeKeyRate(gates);

      std::vector <double> noise;
      protocol->computeErrorRate(gates, noise);

      double err = 0;
      double maxNoise = -1;
      double avgNoise = 0;
      double avgNoiseCount = 0;
      for(int i=0; i<noise.size(); ++i){
	if(fabs(noise[i]-targetNoise) > maxNoise)
	  maxNoise = fabs(noise[i]-targetNoise);
	err += ((noise[i]-targetNoise)*(noise[i]-targetNoise));
	avgNoise += noise[i];
	avgNoiseCount += 1.0;
      }

      avgNoise = avgNoise / avgNoiseCount;

      avgNoise = avgNoise - targetNoise;
      // Nov. 23: this seems to work well for BB84 when tr = -.1, tn = 0
      double Pr = .75; // .55 for bb84biased
      double Pe = (1-Pr);
      //fitness = Pr*(rate + .01)*(rate + .01) + Pe*err;
      //fitness = Pr*(rate + .05)*(rate + .05) + Pe*maxNoise*maxNoise;
      fitness = Pr*(rate - targetRate)*(rate - targetRate) + Pe*avgNoise*avgNoise + Pe*maxNoise*maxNoise;


      Pr = .55; // .55 for bb84biased
      Pe = (1-Pr);
      fitness = Pr*(rate - targetRate)*(rate - targetRate) + Pe*avgNoise*avgNoise;

      //fitness += .1*fabs(noise[0] - noise[1]);

      return fitness;
    }

    bool operator< (const CS& other)
    {
      if(fitness < other.fitness)
	return true;
      return false;
    }

    int numWires;
    double fitness;
  };

  struct GAOutput
  {
    double avgBest;
    double noiseOut;
  };

  class GA
  {
  public:
    void setupPopulation(Protocol* protocol, int MaxPopulation);
    GAOutput evolve(Protocol* protocol, int MaxGenerations, double tol, int HC);

  private:
    int maxPopulation;
    std::list <CS> population;
  };
}
}
